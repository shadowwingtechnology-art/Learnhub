<?php
declare(strict_types=1);
// LearnHub demo API. GET returns project XML; POST saves a demo JSON submission.
// Before production use, add authentication, validation, CSRF protection, rate limiting and a database.
header('X-Content-Type-Options: nosniff');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
 header('Content-Type: application/xml; charset=utf-8');
 readfile(__DIR__ . '/data.xml'); exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
 http_response_code(405); header('Allow: GET, POST'); header('Content-Type: application/json'); echo json_encode(['ok'=>false,'error'=>'Method not allowed']); exit;
}
header('Content-Type: application/json; charset=utf-8');
$payload=json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($payload)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Send a JSON object']); exit; }
$allowed=['name','email','message','task','product','course','url','action'];
$item=[];
foreach ($allowed as $key) if (isset($payload[$key]) && is_scalar($payload[$key])) $item[$key]=substr(trim((string)$payload[$key]),0,1000);
$item['_received_at']=gmdate('c');
$file=__DIR__.'/submissions.json'; $items=[];
if (is_file($file)) { $old=json_decode((string)file_get_contents($file),true); if (is_array($old)) $items=$old; }
$items[]=$item;
if (file_put_contents($file,json_encode($items,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX)===false) { http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Unable to save']); exit; }
echo json_encode(['ok'=>true,'message'=>'Demo submission saved']);
